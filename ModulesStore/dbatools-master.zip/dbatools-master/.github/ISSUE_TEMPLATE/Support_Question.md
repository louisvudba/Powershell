---
name: "❓ Support Question"
about: If you have a question you may try asking on StackExchange network or dbatools
  channel in sqlcommunity.slack.com
title: ''
labels: Question
assignees: ''

---

- Slack Community Channel: https://sqlcommunity.slack.com/messages/C1M2WEASG/ (get an invite: https://dbatools.io/slack/)
- Documentation within the module: `Get-Help <command>`
- Database Administrator on Stack Exchange network, dbatools tag: https://dba.stackexchange.com/questions/tagged/dbatools
- StackOverflow dbatools tag: https://stackoverflow.com/questions/tagged/dbatools
