---
name: "❤️ Say thank you"
about: Tell us how you use dbatools & support our efforts in maintaining dbatools
title: ''
labels: ''
assignees: ''

---

# ❤️ I'm using dbatools

If you (or your company) are using dbatools - please let us know. We'd love to hear from you!

dbatools is a community driven project, which means it's not maintained by a company. If you would like to help dbatools - any of the following is greatly appreciated.

- [ ] Give the repository a star ⭐️
- [ ] Help out with issues
- [ ] Review pull requests
- [ ] Blog about dbatools
- [ ] Make tutorials
- [ ] Give talks
- [ ] Support us on [https://opencollective.com/dbatools](https://opencollective.com/dbatools)
- [ ] [Sponsor one of our developers](https://github.com/sqlcollaborative/dbatools?sponsor=1)

Thank you! 💐
