---
name: "\U0001F64B Feature request"
about: Suggest an idea for this project
title: ''
labels: Feature
assignees: ''

---

---
name: Feature request/idea :bomb:
about: Suggest a new feature or enhancement

---

### Summary of new feature

* Clear/concise description of what the problem is that the new feature can solve.

### Proposed technical details (if applicable)

* e.g. Blog post reference that shows example code or functionality

### Latest version of dbatools as of writing

* Please provide the latest released version of dbatools module.
